"""Ethics and consent handling for the creative assistant.

This module defines simple classes for tracking user consent and applying
speculation labels.  In a production system you would likely persist the
consent ledger to disk and enforce restrictions on storage and sharing.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List


@dataclass
class ConsentLedger:
    """Record of user consent decisions and data retention policies."""

    entries: List[str] = field(default_factory=list)

    def record(self, consent: str) -> None:
        """Add a new consent entry to the ledger."""
        self.entries.append(consent)

    def list_entries(self) -> List[str]:
        """Return all consent entries."""
        return list(self.entries)
