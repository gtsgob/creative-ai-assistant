"""Top-level package for the Creative AI Assistant.

This package exposes classes and utilities to build a co‑evolving creative assistant.  See
individual modules for details.
"""
