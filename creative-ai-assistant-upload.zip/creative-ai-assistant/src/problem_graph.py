"""Simple problem graph implementation.

The problem graph captures the structure of a project: its key claims, questions,
assumptions, and their interdependencies.  It is intentionally lightweight and uses
NetworkX under the hood for graph operations.  You can extend this class to
support more complex relationships or metadata as needed.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Iterable, List

import networkx as nx


@dataclass
class ProblemGraph:
    """A directed graph representing a network of claims and dependencies."""

    name: str
    initial_claims: Iterable[str] = field(default_factory=list)

    def __post_init__(self) -> None:
        self.graph = nx.DiGraph()
        for claim in self.initial_claims:
            self.add_claim(claim)

    def add_claim(self, claim: str) -> None:
        """Add a claim or question to the graph as a node."""
        if claim not in self.graph:
            self.graph.add_node(claim, kind="claim")

    def add_dependency(self, claim: str, depends_on: str) -> None:
        """Add a directed edge indicating that ``claim`` depends on ``depends_on``."""
        self.add_claim(claim)
        self.add_claim(depends_on)
        self.graph.add_edge(depends_on, claim)

    def get_claims(self) -> List[str]:
        """Return a list of all claim nodes in the graph."""
        return [n for n, attrs in self.graph.nodes(data=True) if attrs.get("kind") == "claim"]

    def visualize(self) -> None:
        """Placeholder for a graph visualization method.

        In a real system you might output an interactive D3 graph or export to a format
        understood by a visualization library.  Here, we simply print the adjacency list.
        """
        for source, targets in self.graph.adjacency():
            print(f"{source} -> {list(targets)}")
