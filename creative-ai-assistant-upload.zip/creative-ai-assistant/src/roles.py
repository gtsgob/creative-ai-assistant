"""Role definitions and session orchestration for the creative assistant.

The ``AgentSession`` class provides a high-level interface for interacting with
the various components of the system.  It glues together the user model,
problem graph, divergence, convergence, reflection, and ethics modules.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, Iterable, List, Tuple

from . import problem_graph as pg
from . import divergence as div
from . import convergence as conv
from . import reflection as refl
from . import ethics as eth


class AgentSession:
    """Represents an interactive session with the creative assistant.

    Parameters
    ----------
    user_model_path: str
        Path to the JSON file containing the user's model (goals, constraints, style,
        and other preferences).
    """

    def __init__(self, user_model_path: str) -> None:
        self.user_model_path = Path(user_model_path)
        self.user_model: Dict[str, Any] = self._load_user_model()
        self.problem_graphs: Dict[str, pg.ProblemGraph] = {}
        self.reflection = refl.ReflectionLogger()
        self.ethics = eth.ConsentLedger()

    def _load_user_model(self) -> Dict[str, Any]:
        if self.user_model_path.exists():
            import json
            with open(self.user_model_path, "r", encoding="utf-8") as fh:
                return json.load(fh)
        return {}

    def create_problem_graph(self, name: str, claims: Iterable[str] | None = None) -> pg.ProblemGraph:
        """Create and register a new problem graph.

        Parameters
        ----------
        name: str
            The name of the project or problem.
        claims: iterable of str, optional
            Initial claims or questions to seed the graph.

        Returns
        -------
        ProblemGraph
            The created problem graph instance.
        """
        graph = pg.ProblemGraph(name, claims or [])
        self.problem_graphs[name] = graph
        return graph

    def diverge(self, topic: str, n: int = 10, novelty: float = 0.5) -> List[str]:
        """Generate a list of ideas related to a topic using the divergence engine.

        Parameters
        ----------
        topic: str
            The subject or seed for idea generation.
        n: int, default=10
            Number of ideas to generate.
        novelty: float, default=0.5
            Weighting of novelty in the generation process (0–1).
        """
        return div.generate_ideas(topic=topic, n=n)

    def converge(self, ideas: Iterable[str], novelty: float = 0.5, usefulness: float = 0.5) -> List[Tuple[str, float]]:
        """Rank a list of ideas based on novelty and usefulness.

        Parameters
        ----------
        ideas: iterable of str
            The ideas to rank.
        novelty: float, default=0.5
            Weight given to novelty when scoring ideas.
        usefulness: float, default=0.5
            Weight given to usefulness when scoring ideas.

        Returns
        -------
        list of (str, float)
            The ideas along with their combined scores, sorted in descending order.
        """
        return conv.rank_ideas(list(ideas), novelty=novelty, usefulness=usefulness)

    def reflect(self, notes: str) -> None:
        """Record reflection notes for the current session.

        Parameters
        ----------
        notes: str
            A freeform string capturing lessons learned, surprises, or actions to take.
        """
        self.reflection.log(notes)
