"""Reflection logger for capturing session notes and learnings.

The reflection logger writes freeform notes to an internal list and exposes a method to
retrieve or persist them.  In a more advanced system this could integrate with
persistent storage or analytics for long‑term pattern mining.
"""

from __future__ import annotations

from typing import List


class ReflectionLogger:
    """Collect and store reflection notes for a session."""

    def __init__(self) -> None:
        self._notes: List[str] = []

    def log(self, note: str) -> None:
        """Append a note to the reflection log."""
        self._notes.append(note)

    def get_notes(self) -> List[str]:
        """Return all recorded notes."""
        return list(self._notes)

    def clear(self) -> None:
        """Clear the reflection log."""
        self._notes.clear()
