"""Convergence engine for ranking ideas.

This module provides functions for evaluating and ranking a list of ideas based on
their novelty and usefulness.  The current implementation uses simple heuristics
as placeholders; adapt these functions to incorporate your own scoring models or
embedding-based similarity measures.
"""

from __future__ import annotations

from typing import Iterable, List, Tuple


def _score_novelty(idea: str) -> float:
    """Assign a novelty score based on the idea's length.

    This heuristic is purely illustrative — longer ideas are assumed to be more
    novel, but in practice you would use embeddings or other metrics.
    """
    return min(len(idea) / 100.0, 1.0)


def _score_usefulness(idea: str) -> float:
    """Assign a usefulness score based on the number of words.

    Again, this is a placeholder.  More words are considered more useful for
    demonstration purposes.
    """
    return min(len(idea.split()) / 20.0, 1.0)


def rank_ideas(ideas: Iterable[str], novelty: float = 0.5, usefulness: float = 0.5) -> List[Tuple[str, float]]:
    """Rank ideas based on weighted novelty and usefulness scores.

    Parameters
    ----------
    ideas: iterable of str
        The ideas to rank.
    novelty: float, default=0.5
        Weight given to novelty in the final score.
    usefulness: float, default=0.5
        Weight given to usefulness in the final score.

    Returns
    -------
    list of (idea, score)
        A list of tuples containing ideas and their combined scores, sorted by
        descending score.
    """
    scored: List[Tuple[str, float]] = []
    for idea in ideas:
        nov_score = _score_novelty(idea)
        use_score = _score_usefulness(idea)
        total = novelty * nov_score + usefulness * use_score
        scored.append((idea, total))
    return sorted(scored, key=lambda x: x[1], reverse=True)
