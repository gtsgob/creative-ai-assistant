"""Taste distillation utilities.

This module provides a minimal stub for learning a user's aesthetic preferences from
a set of positive and negative examples.  The provided ``TasteDistiller`` class
collects embeddings from text files and computes a simple difference vector.  In
a production system you would replace this with a proper contrastive model.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Iterable

import json


@dataclass
class TasteDistiller:
    """Compute a simple taste rubric from liked and disliked examples."""

    yes_dir: str
    no_dir: str

    def train(self) -> Dict[str, float]:
        """Train a dummy taste model.

        The current implementation simply counts the number of files in the yes and no
        directories and uses the difference as a proxy metric.  Replace this with
        embedding extraction and contrastive learning for real use cases.
        """
        yes_count = len(list(Path(self.yes_dir).glob("*")))
        no_count = len(list(Path(self.no_dir).glob("*")))
        score = yes_count - no_count
        return {"score": score}

    def save(self, output_path: str, rubric: Dict[str, float]) -> None:
        """Save the rubric to a JSON file."""
        with open(output_path, "w", encoding="utf-8") as fh:
            json.dump(rubric, fh, indent=2)
