"""Divergence engine for generating creative ideas.

This module contains simple functions that take a topic and return a list of ideas.  The
implementation here is intentionally naive — in a real system you might integrate
large language models or domain-specific generators.  Use this as a starting point
and replace with your preferred generation technique.
"""

from __future__ import annotations

from typing import List


def generate_ideas(topic: str, n: int = 10) -> List[str]:
    """Generate a list of naive ideas based on the provided topic.

    Parameters
    ----------
    topic: str
        The seed topic for idea generation.
    n: int, default=10
        The number of ideas to generate.

    Returns
    -------
    list of str
        A list of generated idea strings.
    """
    ideas: List[str] = []
    for i in range(1, n + 1):
        ideas.append(f"Idea {i} for {topic}")
    return ideas
