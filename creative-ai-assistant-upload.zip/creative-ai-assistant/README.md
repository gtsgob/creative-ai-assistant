# Creative AI Assistant

This repository contains a minimal scaffold for a co‑evolving cognitive assistant.  It is designed to
help you bootstrap a system capable of maintaining a user model, building problem graphs,
generating novel ideas through divergence, ranking them through convergence, and recording
reflections for iterative improvement.

## Structure

* `notebooks/` – Jupyter notebooks for interactive exploration.  The `core_mvp.ipynb` notebook
  demonstrates how to wire together the main components of the system.
* `src/` – The Python source code for the assistant.  Each file in this package provides a
  specific capability, such as user modeling, problem graph management, divergence generation,
  convergence ranking, reflection logging, and ethics/consent handling.
* `data/` – Example data files, including a placeholder user model and consent ledger.  These
  files should be edited by the user to match their personal preferences and project goals.

## Getting Started

To get started, install the dependencies listed in `requirements.txt` and open the
`notebooks/core_mvp.ipynb` notebook in Jupyter.  The notebook will walk you through
initializing an `AgentSession`, constructing a problem graph for your project, generating
candidate ideas, and ranking them according to novelty and usefulness.

Feel free to customise the code in `src/` to suit your own creative workflows.  The provided
classes and functions are deliberately simple and intended as a starting point rather than a
complete solution.
