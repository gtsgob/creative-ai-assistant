# Consent Ledger

This file contains a record of all consent decisions made by the user.  Each line
represents a specific action that the assistant was permitted or denied, along
with the timestamp and any relevant context.

*No entries yet.*
